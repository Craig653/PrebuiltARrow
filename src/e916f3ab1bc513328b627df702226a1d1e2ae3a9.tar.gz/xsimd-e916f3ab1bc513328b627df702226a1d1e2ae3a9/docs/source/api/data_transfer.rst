.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay 

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Data transfer
=============

Data transfer instructions
--------------------------

.. doxygengroup:: data_transfer
   :project: xsimd
   :content-only:

Generic load and store
----------------------

.. doxygengroup:: generic_load_store
   :project: xsimd
   :content-only:

