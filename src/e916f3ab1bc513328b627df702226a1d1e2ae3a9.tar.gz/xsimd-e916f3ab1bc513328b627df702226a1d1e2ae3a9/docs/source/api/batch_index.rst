.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay 

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Wrapper types
=============

.. toctree::

   xsimd_base
   xsimd_batch_bool
   xsimd_batch
   xsimd_complex_bool_base
   xsimd_complex_base
   available_wrappers
