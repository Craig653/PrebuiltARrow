.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Classification functions
========================

.. _isfinite-func-ref:
.. doxygenfunction:: isfinite
   :project: xsimd

.. _isinf-func-ref:
.. doxygenfunction:: isinf
   :project: xsimd

.. _isnan-func-ref:
.. doxygenfunction:: isnan(const simd_base<X>&)
   :project: xsimd

