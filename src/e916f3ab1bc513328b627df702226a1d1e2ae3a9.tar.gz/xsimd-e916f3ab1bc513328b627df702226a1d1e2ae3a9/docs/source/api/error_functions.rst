.. Copyright (c) 2016, Johan Mabille, Sylvain Corlay

   Distributed under the terms of the BSD 3-Clause License.

   The full license is in the file LICENSE, distributed with this software.

Error and gamma functions
=========================

.. _erf-function-reference:
.. doxygenfunction:: erf
   :project: xsimd

.. _erfc-function-reference:
.. doxygenfunction:: erfc
   :project: xsimd

.. _tgamma-func-ref:
.. doxygenfunction:: tgamma
   :project: xsimd

.. _lgamma-func-ref:
.. doxygenfunction:: lgamma
   :project: xsimd
